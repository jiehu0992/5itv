<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
	<div>
		<ul class="nav navbar-nav">
			<li><a href="/os.php">欧式族谱</a></li>		
			<li><a href="/bt.php">塔式族谱</a></li>	
			<li><a href="/search.php">搜索</a></li>
		</ul>
	</div>
	</div>
</nav>