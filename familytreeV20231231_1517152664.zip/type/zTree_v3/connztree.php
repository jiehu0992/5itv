<?php
	//ztree样式数据库连接
	require_once '../../conn.php';  // 使用相对路径引入数据库连接信息

	$sql = 'SELECT * FROM tree_lr';
	$res = mysqli_query($link, $sql);

	if (!$res) {
	    die('Error: ' . mysqli_error($link));
	}

	$array = array();
	while ($row = mysqli_fetch_row($res)) {
	    $menu = array(
	        "id" => $row[0],
	        "pId" => $row[1],
	        "name" => urlencode($row[2]),  // 直接使用从数据库读取的字符串
	        "open" => 1,
	        "file" => $row[4],
	    );
	    array_push($array, $menu);
	}

	echo json_encode($array);

	mysqli_close($link);
?>
