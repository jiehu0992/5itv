-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 
-- 服务器版本: 5.5.53
-- PHP 版本: 7.4.32

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `familytree`
--

-- --------------------------------------------------------

--
-- 表的结构 `tree_lr`
--

CREATE TABLE IF NOT EXISTS `tree_lr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(30) NOT NULL DEFAULT '',
  `L` int(6) DEFAULT NULL,
  `R` int(6) DEFAULT NULL,
  `dorder` int(6) DEFAULT NULL,
  `sex` varchar(10) DEFAULT '男',
  `wname` varchar(255) DEFAULT NULL,
  `winfo` varchar(60) DEFAULT NULL,
  `dad` varchar(255) DEFAULT NULL,
  `gdad` varchar(255) DEFAULT NULL,
  `mother` varchar(255) DEFAULT NULL,
  `dc` smallint(6) unsigned NOT NULL DEFAULT '0',
  `zibei` varchar(255) DEFAULT NULL,
  `rank` varchar(255) DEFAULT NULL,
  `line` varchar(6) NOT NULL DEFAULT '' COMMENT '自然排行',
  `brother` varchar(255) DEFAULT NULL,
  `sisters` varchar(255) DEFAULT NULL,
  `son` varchar(255) DEFAULT NULL,
  `daughter` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  `dieday` varchar(255) DEFAULT NULL,
  `lifeadresse` varchar(255) DEFAULT NULL,
  `mudi` varchar(255) DEFAULT NULL,
  `tongxun` varchar(255) DEFAULT NULL,
  `nation` varchar(255) DEFAULT NULL,
  `birthadresse` varchar(255) DEFAULT NULL,
  `zi` varchar(255) DEFAULT NULL,
  `hao` varchar(255) DEFAULT NULL,
  `jiguan` varchar(255) DEFAULT NULL,
  `rname` varchar(255) DEFAULT NULL,
  `marriage` varchar(255) DEFAULT NULL,
  `zhiye` varchar(255) DEFAULT NULL,
  `xueli` varchar(255) DEFAULT NULL,
  `other` text,
  `jisi` varchar(255) DEFAULT NULL,
  `tongji` varchar(255) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dc` (`dc`),
  KEY `L` (`L`),
  KEY `name` (`name`),
  KEY `pid` (`pid`),
  KEY `R` (`R`),
  KEY `sex` (`sex`),
  KEY `winfo` (`winfo`),
  KEY `wname` (`wname`),
  KEY `zibei` (`zibei`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `tree_lr`
--

INSERT INTO `tree_lr` (`id`, `pid`, `name`, `L`, `R`, `dorder`, `sex`, `wname`, `winfo`, `dad`, `gdad`, `mother`, `dc`, `zibei`, `rank`, `line`, `brother`, `sisters`, `son`, `daughter`, `year`, `dieday`, `lifeadresse`, `mudi`, `tongxun`, `nation`, `birthadresse`, `zi`, `hao`, `jiguan`, `rname`, `marriage`, `zhiye`, `xueli`, `other`, `jisi`, `tongji`, `info`) VALUES
(1, 0, '始祖', 1, 14, 1, '男', '失考', '失考||||||', '', '未找到祖父', '', 1, '價', '長子', '', '', '', '测试1', '', '', '', '', '', '', '', '', '', '', '四川省邻水县', '', '', '', '', '', '', '', '，生子测试1。'),
(2, 1, '测试1', 2, 13, 2, '男', '', '||||||', '始祖', '未找到祖父', '', 2, '壽', '長子', '', '', '', '测试2、测试3', '', '', '', '', '', '', '', '', '', '', '四川省邻水县', '', '', '', '', '', '', '', '，生子测试2、测试3。'),
(3, 2, '测试2', 3, 4, 3, '男', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 2, '测试3', 5, 12, 4, '男', '', '||||||', '测试1', '始祖', '', 3, '尚', '長子', '', '测试2', '', 'test4、test5', '', '', '', '', '', '', '', '', '', '', '四川省邻水县', '', '', '', '', '', '', '', '，生子test4、test5。'),
(5, 4, 'test4', 6, 7, 5, '男', '', '||||||', '测试3', '测试1', '', 4, '季', '長子', '', 'test5', '', '', '', '', '', '', '', '', '', '', '', '', '四川省邻水县', '', '', '', '', '', '', '', ''),
(6, 4, 'test5', 8, 9, 6, '男', '', '||||||', '测试3', '测试1', '', 4, '季', '次子', '', 'test4', '', '', '', '', '', '', '', '', '', '', '', '', '四川省邻水县', '', '', '', '', '', '', '', ''),
(7, 4, 'test6', 10, 11, 7, '女', '', '||||||', '测试3', '测试1', '', 4, '季', '長女', '', 'test4、test5', '', '', '', '', '', '', '', '', '', '', '', '', '四川省邻水县', '', '', '', '', '', '', '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
