-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 19, 2020 at 05:06 AM
-- Server version: 5.5.53
-- PHP Version: 5.6.27

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tree`
--

-- --------------------------------------------------------

--
-- Table structure for table `tree_lr`
--

CREATE TABLE IF NOT EXISTS `tree_lr` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(30) NOT NULL DEFAULT '',
  `L` int(6) DEFAULT NULL,
  `R` int(6) DEFAULT NULL,
  `dorder` int(6) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `wname` varchar(255) DEFAULT NULL,
  `dad` varchar(255) DEFAULT NULL,
  `gdad` varchar(255) DEFAULT NULL,
  `mother` varchar(255) DEFAULT NULL,
  `dc` smallint(6) unsigned DEFAULT NULL,
  `zibei` varchar(255) DEFAULT NULL,
  `rank` varchar(255) DEFAULT NULL,
  `line` varchar(6) NOT NULL DEFAULT '' COMMENT '自然排行',
  `brother` varchar(255) DEFAULT NULL,
  `sisters` varchar(255) DEFAULT NULL,
  `son` varchar(255) DEFAULT NULL,
  `daughter` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  `dieday` varchar(255) DEFAULT NULL,
  `lifeadresse` varchar(255) DEFAULT NULL,
  `mudi` varchar(255) DEFAULT NULL,
  `tongxun` varchar(255) DEFAULT NULL,
  `nation` varchar(255) DEFAULT NULL,
  `birthadresse` varchar(255) DEFAULT NULL,
  `zi` varchar(255) DEFAULT NULL,
  `hao` varchar(255) DEFAULT NULL,
  `jiguan` varchar(255) DEFAULT NULL,
  `rname` varchar(255) DEFAULT NULL,
  `marriage` varchar(255) DEFAULT NULL,
  `zhiye` varchar(255) DEFAULT NULL,
  `xueli` varchar(255) DEFAULT NULL,
  `other` text,
  `jisi` varchar(255) DEFAULT NULL,
  `tongji` varchar(255) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
